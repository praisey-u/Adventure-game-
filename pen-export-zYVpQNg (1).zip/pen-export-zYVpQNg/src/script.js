let currentScene = "start";

function processInput() {
    const userInput = document.getElementById('userInput').value.toLowerCase();
    const storyElement = document.getElementById('story');
    const sceneImage = document.getElementById('sceneImage');

    switch (currentScene) {
        case "start":
            if (userInput === "left") {
                storyElement.textContent = "You walk into a room full of treasures! But beware, there is also a sleeping dragon. What do you do?";
                sceneImage.src = "treasureRoom.png";
                sceneImage.alt = "Treasure Room";
                currentScene = "treasureRoom";
            } else if (userInput === "right") {
                storyElement.textContent = "You enter a dark tunnel that seems to go on forever. Do you continue walking or turn back?";
                sceneImage.src = "tunnel.png";
                sceneImage.alt = "Endless Tunnel";
                currentScene = "tunnel";
            } else {
                storyElement.textContent = "Please choose 'left' or 'right'.";
            }
            break;

        case "treasureRoom":
            if (userInput === "take the treasure") {
                storyElement.textContent = "You carefully take the treasure, but the dragon wakes up and you have to run for your life! You barely escape. The End.";
                sceneImage.src = "dragon.png";
                sceneImage.alt = "Dragon Wakes Up";
                currentScene = "end";
            } else if (userInput === "leave quietly") {
                storyElement.textContent = "You wisely decide to leave quietly. You exit the room safely and continue your adventure. The End.";
                sceneImage.src = "safeExit.png";
                sceneImage.alt = "Safe Exit";
                currentScene = "end";
            } else {
                storyElement.textContent = "Please choose to 'take the treasure' or 'leave quietly'.";
            }
            break;

        case "tunnel":
            if (userInput === "continue walking") {
                storyElement.textContent = "You keep walking, but the tunnel never ends. You're lost in the darkness forever. The End.";
                sceneImage.src = "lost.png";
                sceneImage.alt = "Lost Forever";
                currentScene = "end";
            } else if (userInput === "turn back") {
                storyElement.textContent = "You turn back and find your way out of the tunnel. You decide to head home. The End.";
                sceneImage.src = "escape.png";
                sceneImage.alt = "Escape";
                currentScene = "end";
            } else {
                storyElement.textContent = "Please choose to 'continue walking' or 'turn back'.";
            }
            break;

        case "end":
            if (userInput === "restart") {
                storyElement.textContent = "You are standing in a dark room. There are doors to the left and right. What do you do?";
                sceneImage.src = "start.png";
                sceneImage.alt = "Starting Room";
                currentScene = "start";
            } else {
                storyElement.textContent = "Type 'restart' to play again.";
            }
            break;

        default:
            storyElement.textContent = "An error occurred. Please refresh the page.";
    }

    document.getElementById('userInput').value = ''; // Clear the input field
}
